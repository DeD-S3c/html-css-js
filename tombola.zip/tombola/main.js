const MAX_NUMERI = 90;
const state = {
  estratti: new Set(),
  ultimo: null
};

const boardEl = document.getElementById('board');
const btnEstrai = document.getElementById('btnEstrai');
const btnReset = document.getElementById('btnReset');
const countEl = document.getElementById('countEstratti');
const ultimoEl = document.getElementById('ultimoNumero');
const listaEl = document.getElementById('listaEstratti');
const progressEl = document.getElementById('progressBar');
const statusEl = document.getElementById('statusText');

initBoard();

btnEstrai.addEventListener('click', estraiNumero);
btnReset.addEventListener('click', reset);

function initBoard() {
  const fragment = document.createDocumentFragment();
  for (let n = 1; n <= MAX_NUMERI; n++) {
    const cell = document.createElement('div');
    cell.className = 'cell';
    cell.dataset.num = String(n);
    cell.textContent = n;
    fragment.appendChild(cell);
  }
  boardEl.appendChild(fragment);
  updateUI();
}

function estraiNumero() {
  if (state.estratti.size >= MAX_NUMERI) return;

  const numero = pickRandomNonEstratto();
  if (numero == null) return;

  state.estratti.add(numero);
  state.ultimo = numero;

  highlightCell(numero);
  appendBadge(numero);
  updateUI({ animateBall: true });
}

function pickRandomNonEstratto() {
  const rimanenti = [];
  for (let n = 1; n <= MAX_NUMERI; n++) {
    if (!state.estratti.has(n)) rimanenti.push(n);
  }
  if (rimanenti.length === 0) return null;

  const idx = Math.floor(Math.random() * rimanenti.length);
  return rimanenti[idx];
}

function reset() {
  state.estratti.clear();
  state.ultimo = null;

  boardEl.querySelectorAll('.cell').forEach(cell => {
    cell.classList.remove('hit', 'is-new');
  });
  listaEl.innerHTML = '';
  updateUI();
}

function highlightCell(numero) {
  const cell = boardEl.querySelector(`.cell[data-num="${numero}"]`);
  if (!cell) return;
  cell.classList.add('hit');
  cell.classList.remove('is-new');
  void cell.offsetWidth; // reset animation state
  cell.classList.add('is-new');
  cell.addEventListener(
    'animationend',
    () => cell.classList.remove('is-new'),
    { once: true }
  );
}

function appendBadge(numero) {
  const badge = document.createElement('span');
  badge.className = 'badge';
  badge.textContent = numero;
  listaEl.appendChild(badge);

  if (typeof listaEl.scrollTo === 'function') {
    listaEl.scrollTo({
      top: listaEl.scrollHeight,
      behavior: 'smooth'
    });
  }
}

function updateUI(options = {}) {
  const { animateBall = false } = options;
  const estratti = state.estratti.size;

  countEl.textContent = String(estratti);
  if (state.ultimo == null) {
    ultimoEl.textContent = '—';
    ultimoEl.classList.remove('pop');
  } else {
    ultimoEl.textContent = String(state.ultimo);
    if (animateBall) triggerBallAnimation();
  }

  const finiti = estratti >= MAX_NUMERI;
  btnEstrai.disabled = finiti;
  btnEstrai.textContent = finiti ? 'Completato' : 'Estrai numero';
  updateProgressBar(estratti);
  updateStatus(estratti);
}

function updateProgressBar(count) {
  const percent = Math.min(100, (count / MAX_NUMERI) * 100);
  if (progressEl) {
    progressEl.style.width = `${percent}%`;
  }
}

function updateStatus(count) {
  if (!statusEl) return;
  statusEl.textContent = buildStatusMessage(count);
}

function buildStatusMessage(count) {
  const remaining = MAX_NUMERI - count;
  if (count === 0) return 'Pronto all\'estrazione';
  if (count < 30) return `Partenza brillante! ${count} numeri già usciti.`;
  if (count < 60) return `Siamo a metà strada: mancano ${remaining} numeri.`;
  if (count < 80) return `Il ritmo si scalda! Restano ${remaining} numeri.`;
  if (count < MAX_NUMERI) return `Finale incandescente: ultimi ${remaining} numeri in gioco.`;
  return 'Tutti i numeri sono stati estratti! 🎉';
}

function triggerBallAnimation() {
  ultimoEl.classList.remove('pop');
  void ultimoEl.offsetWidth;
  ultimoEl.classList.add('pop');
}
